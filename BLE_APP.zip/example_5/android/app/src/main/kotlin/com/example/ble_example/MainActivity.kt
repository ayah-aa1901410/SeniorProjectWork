package com.example.ble_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
